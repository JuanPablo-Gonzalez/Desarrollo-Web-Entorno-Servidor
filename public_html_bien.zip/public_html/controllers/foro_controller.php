<?php
    session_start();

    include_once "../db/db.php";
    //include_once "../models/foro_model.php";
    include_once "../views/foro_view.html";
?>