<?php
header('Location: ' . "controllers/login_controller.php");
die();
//include_once "controllers/login_controller.php";
?>